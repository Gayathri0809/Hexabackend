package com.backend.cafe.controller;
import java.util.List;

import com.backend.cafe.entity.OrderHistory;
import com.backend.cafe.exception.UserNotFoundException;
import com.backend.cafe.repository.OderHistoryRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
@CrossOrigin
public class OrderHistoryController {
	 private static final Logger logger = LoggerFactory.getLogger(OrderHistoryController.class);

	@Autowired
    private OderHistoryRepository ohRepository;
	 @GetMapping("/history")
     
	    List<OrderHistory> getAllUsers() {
		 logger.info("Getting all order history records.");
	        return ohRepository.findAll();
	    }
	 @PostMapping("/history")
	    OrderHistory newMenu(@RequestBody OrderHistory newOrderHistory) {
		 
	        return ohRepository.save( newOrderHistory);
	    }
	 @DeleteMapping("/history/{id}")
	    String deleteItem(@PathVariable Long id){
	        if(!ohRepository.existsById(id)){
	            throw new UserNotFoundException(id);
	        }
	        ohRepository.deleteById(id);
	        return  "User with id "+id+" has been deleted success.";
	    }
}
