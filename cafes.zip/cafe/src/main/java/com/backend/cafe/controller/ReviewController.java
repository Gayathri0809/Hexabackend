package com.backend.cafe.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.backend.cafe.entity.Review;
import com.backend.cafe.repository.ReviewRepository;

@RestController
@CrossOrigin
public class ReviewController {
	@Autowired
    private ReviewRepository reviewRepository;
	@PostMapping("/review")
    Review newReview(@RequestBody Review newReview) {
        return reviewRepository.save(newReview);
    }
    @GetMapping("/review")
    List<Review> getAllReview() {
        return reviewRepository.findAll();
    }


}

