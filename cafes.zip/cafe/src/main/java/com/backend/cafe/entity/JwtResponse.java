package com.backend.cafe.entity;

public class JwtResponse {

	private String role;
	private String jwtToken;
	public JwtResponse(String role, String jwtToken) {
		super();
		this.role = role;
		this.jwtToken = jwtToken;
	}
	public String getUser() {
		return role;
	}
	public void setUser(String role) {
		this.role = role;
	}
	public String getJwtToken() {
		return jwtToken;
	}
	public void setJwtToken(String jwtToken) {
		this.jwtToken = jwtToken;
	}
	
}