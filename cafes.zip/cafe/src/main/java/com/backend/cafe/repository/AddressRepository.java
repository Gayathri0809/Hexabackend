package com.backend.cafe.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.backend.cafe.entity.Addres;


public interface AddressRepository extends JpaRepository<Addres,Long> {

}
