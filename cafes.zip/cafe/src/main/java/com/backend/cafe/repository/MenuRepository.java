package com.backend.cafe.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.backend.cafe.entity.Menu;




public interface MenuRepository extends JpaRepository<Menu,Long> {
}


