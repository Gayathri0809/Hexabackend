package com.backend.cafe.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.backend.cafe.entity.OrderHistory;


public interface OderHistoryRepository extends JpaRepository<OrderHistory,Long> {

}
