package com.backend.cafe.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.backend.cafe.entity.Register;


public interface RegisterRepository extends JpaRepository<Register,Integer>{

}
