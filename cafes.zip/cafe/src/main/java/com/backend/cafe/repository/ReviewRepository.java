package com.backend.cafe.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.backend.cafe.entity.Review;

public interface ReviewRepository  extends JpaRepository<Review,Long> {

}
